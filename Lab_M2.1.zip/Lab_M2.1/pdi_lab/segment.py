from __future__ import annotations

import cv2
import numpy as np

METHODS = ("fixed", "otsu", "adaptive", "hsv")


class PdiError(Exception):
    """Erro de uso/entrada: a CLI converte em código de saída != 0."""


def preprocess(gray_or_bgr: np.ndarray, blur: int) -> np.ndarray:
    if blur == 0:
        return gray_or_bgr
    if blur < 0 or blur % 2 == 0:
        raise PdiError(f"--blur deve ser 0 ou inteiro ímpar positivo (recebido {blur})")
    return cv2.GaussianBlur(gray_or_bgr, (blur, blur), 0)

def segment_fixed(bgr, threshold, invert, blur):
    if not (0 <= threshold <= 255):
        raise PdiError(f"--threshold deve estar em [0,255] (recebido {threshold})")
    gray = preprocess(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), blur)
    kind = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
    _, mask = cv2.threshold(gray, threshold, 255, kind)
    return mask, {"threshold": threshold}


def segment_otsu(bgr, invert, blur):
    gray = preprocess(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), blur)
    kind = (cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY) + cv2.THRESH_OTSU
    t, mask = cv2.threshold(gray, 0, 255, kind)
    return mask, {"threshold_otsu": float(t)}


def segment_adaptive(bgr, block_size, c, invert, blur):
    if block_size < 3 or block_size % 2 == 0:
        raise PdiError(f"--block-size deve ser ímpar >= 3 (recebido {block_size})")
    gray = preprocess(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), blur)
    kind = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
    mask = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, kind, block_size, c)
    return mask, {"block_size": block_size, "C": c}


def segment_hsv(bgr, lower, upper, blur):
    for name, v in (("--hsv-lower", lower), ("--hsv-upper", upper)):
        if len(v) != 3:
            raise PdiError(f"{name} requer 3 valores H S V")
        if not (0 <= v[0] <= 179 and 0 <= v[1] <= 255 and 0 <= v[2] <= 255):
            raise PdiError(f"{name} fora da escala OpenCV (H 0-179, S/V 0-255): {v}")
    if lower[1] > upper[1] or lower[2] > upper[2]:
        raise PdiError("--hsv-lower deve ser <= --hsv-upper em S e V")
    hsv = cv2.cvtColor(preprocess(bgr, blur), cv2.COLOR_BGR2HSV)
    lo, hi = np.array(lower, np.uint8), np.array(upper, np.uint8)
    if lower[0] <= upper[0]:
        mask = cv2.inRange(hsv, lo, hi)
    else:
        m1 = cv2.inRange(hsv, lo, np.array([179, upper[1], upper[2]], np.uint8))
        m2 = cv2.inRange(hsv, np.array([0, lower[1], lower[2]], np.uint8), hi)
        mask = cv2.bitwise_or(m1, m2)
    return mask, {"hsv_lower": list(lower), "hsv_upper": list(upper)}


def validate_mask(mask: np.ndarray, shape_hw: tuple[int, int]) -> dict:
    if mask.ndim != 2:
        raise PdiError(f"máscara deve ter 1 canal (ndim={mask.ndim})")
    if mask.shape != tuple(shape_hw):
        raise PdiError(f"dimensões da máscara {mask.shape} != entrada {shape_hw}")
    if mask.dtype != np.uint8:
        raise PdiError(f"máscara deve ser uint8 (dtype={mask.dtype})")
    vals = set(np.unique(mask).tolist())
    if not vals <= {0, 255}:
        raise PdiError(f"máscara com valores fora de {{0,255}}: {sorted(vals)}")
    fg = int(np.count_nonzero(mask == 255))
    return {"foreground_pixels": fg, "total_pixels": int(mask.size),
            "foreground_ratio": fg / mask.size}
