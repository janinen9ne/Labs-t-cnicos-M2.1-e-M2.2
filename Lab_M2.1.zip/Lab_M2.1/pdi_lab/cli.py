from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2

from . import analyze as ana
from . import segment as seg

OPERATIONS = ("segment", "analyze")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="pdi_lab", description="Laboratório PDI (M2.1: segment; M2.2: analyze)")
    p.add_argument("--input", required=True, help="imagem de entrada")
    p.add_argument("--output", required=True, help="segment: máscara PNG de saída; analyze: PREFIXO dos arquivos de saída")
    p.add_argument("--operation", required=True, help="operação: segment | analyze")
    p.add_argument("--method", default="fixed", help="fixed | otsu | adaptive | hsv")
    p.add_argument("--threshold", type=int, default=120, help="fixed: limiar em [0,255]")
    p.add_argument("--invert", action="store_true", help="objeto escuro: inverte a máscara")
    p.add_argument("--blur", type=int, default=0, help="pré-processamento: Gaussiana ksize ímpar (0=nenhum)")
    p.add_argument("--block-size", type=int, default=51, help="adaptive: tamanho do bloco (ímpar >= 3)")
    p.add_argument("--C", type=float, default=5.0, dest="c", help="adaptive: constante subtraída")
    p.add_argument("--hsv-lower", type=int, nargs=3, metavar=("H", "S", "V"),
                   help="hsv: limite inferior (H 0-179, S/V 0-255); H_inf > H_sup cruza o matiz 0")
    p.add_argument("--hsv-upper", type=int, nargs=3, metavar=("H", "S", "V"), help="hsv: limite superior")

    p.add_argument("--connectivity", type=int, default=8, help="analyze: conectividade 4 ou 8 (padrão 8)")
    p.add_argument("--min-area", type=int, default=0,
                   help="analyze: área mínima em pixels para manter o componente (padrão 0 = sem filtro)")
    p.add_argument("--morph", default="",
                   help="analyze: sequência 'op:forma:tamanho:iterações,...' (op: open|close; "
                        "forma: rect|ellipse|cross). Ex.: open:ellipse:5:1,close:ellipse:9:1")
    return p

def run(argv=None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code or 0)
    try:
        if args.operation not in OPERATIONS:
            raise seg.PdiError(f"operação desconhecida: {args.operation!r} (aceita: {OPERATIONS})")
        if args.operation == "analyze":
            steps = ana.parse_morph(args.morph)
            s = ana.run_analyze(args.input, args.output, args.connectivity, args.min_area, steps)
            i, f = s["initial"], s["final"]
            print(f"ok analyze conn={args.connectivity} min_area={args.min_area} "
                  f"inicial: brutos={i['components_raw']} mantidos={i['components_kept']} "
                  f"(conn4={i['raw_conn4']}, conn8={i['raw_conn8']}) | "
                  f"final: brutos={f['components_raw']} mantidos={f['components_kept']} | "
                  f"area_soma_ok={i['area_sum_matches_fg']}")
            return 0
        if args.method not in seg.METHODS:
            raise seg.PdiError(f"método desconhecido: {args.method!r} (aceita: {seg.METHODS})")
        if Path(args.output).suffix.lower() not in (".png", ".bmp", ".tif", ".tiff"):
            raise seg.PdiError("--output deve ser formato sem perdas (.png, .bmp, .tif)")
        bgr = cv2.imread(args.input, cv2.IMREAD_COLOR)
        if bgr is None:
            raise seg.PdiError(f"não foi possível ler a imagem: {args.input}")

        if args.method == "fixed":
            mask, params = seg.segment_fixed(bgr, args.threshold, args.invert, args.blur)
        elif args.method == "otsu":
            mask, params = seg.segment_otsu(bgr, args.invert, args.blur)
        elif args.method == "adaptive":
            mask, params = seg.segment_adaptive(bgr, args.block_size, args.c, args.invert, args.blur)
        else:
            if not args.hsv_lower or not args.hsv_upper:
                raise seg.PdiError("método hsv exige --hsv-lower e --hsv-upper")
            mask, params = seg.segment_hsv(bgr, args.hsv_lower, args.hsv_upper, args.blur)

        stats = seg.validate_mask(mask, bgr.shape[:2])
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(args.output, mask):
            raise seg.PdiError(f"falha ao gravar {args.output}")

        back = cv2.imread(args.output, cv2.IMREAD_UNCHANGED)
        stats = seg.validate_mask(back, bgr.shape[:2])
        stats.update(method=args.method, params=params, blur=args.blur, invert=args.invert)
        print(f"ok method={args.method} fg_pixels={stats['foreground_pixels']} "
              f"fg_ratio={stats['foreground_ratio']:.4f} binary=OK shape={back.shape}")
        return 0
    except seg.PdiError as e:
        print(f"erro: {e}", file=sys.stderr)
        return 1
    except cv2.error as e:
        print(f"erro OpenCV: {e}", file=sys.stderr)
        return 1


def main() -> None:
    sys.exit(run())
