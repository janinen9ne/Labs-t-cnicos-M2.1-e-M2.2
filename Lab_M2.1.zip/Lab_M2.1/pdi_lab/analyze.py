from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import cv2
import numpy as np

from .segment import PdiError, validate_mask

MORPH_OPS = {"open": cv2.MORPH_OPEN, "close": cv2.MORPH_CLOSE}
SHAPES = {"rect": cv2.MORPH_RECT, "ellipse": cv2.MORPH_ELLIPSE, "cross": cv2.MORPH_CROSS}
CSV_FIELDS = ["label", "area", "x", "y", "width", "height", "cx", "cy", "kept"]

@dataclass(frozen=True)
class MorphStep:
    op: str
    shape: str
    size: int
    iterations: int = 1


def validate_step(s: MorphStep) -> MorphStep:
    if s.op not in MORPH_OPS:
        raise PdiError(f"operação morfológica desconhecida")
    if s.shape not in SHAPES:
        raise PdiError(f"forma de elemento estruturante desconhecida")
    if not isinstance(s.size, int) or s.size < 1 or s.size % 2 == 0:
        raise PdiError(f"tamanho do elemento estruturante deve ser inteiro ímpar >= 1")
    if not isinstance(s.iterations, int) or s.iterations < 1:
        raise PdiError(f"iterações deve ser inteiro >= 1")
    return s


def parse_morph(spec: str) -> list[MorphStep]:
    steps = []
    for item in filter(None, (t.strip() for t in spec.split(","))):
        parts = item.split(":")
        if len(parts) > 4:
            raise PdiError(f"--morph: passo inválido {item!r} (use op:forma:tamanho:iterações)")
        parts += [None] * (4 - len(parts))
        try:
            size = 3 if parts[2] is None else int(parts[2])
            it = 1 if parts[3] is None else int(parts[3])
        except ValueError:
            raise PdiError(f"--morph: tamanho e iterações devem ser inteiros em {item!r}")
        steps.append(validate_step(MorphStep(parts[0], parts[1] or "ellipse", size, it)))
    return steps


def apply_step(mask: np.ndarray, step: MorphStep) -> np.ndarray:
    kernel = cv2.getStructuringElement(SHAPES[step.shape], (step.size, step.size))
    return cv2.morphologyEx(mask, MORPH_OPS[step.op], kernel, iterations=step.iterations)


def count_holes(mask: np.ndarray) -> int:
    n, labels, stats, _ = cv2.connectedComponentsWithStats((mask == 0).astype(np.uint8), connectivity=4)
    h, w = mask.shape
    holes = 0
    for i in range(1, n):
        x, y = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP]
        bw, bh = stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        if x > 0 and y > 0 and x + bw < w and y + bh < h:
            holes += 1
    return holes

def label_components(mask: np.ndarray, connectivity: int, min_area: int = 0):
    if connectivity not in (4, 8):
        raise PdiError(f"--connectivity deve ser 4 ou 8 (recebido {connectivity})")
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, connectivity=connectivity, ltype=cv2.CV_32S)
    rows = []
    for i in range(1, n):
        area = int(stats[i, cv2.CC_STAT_AREA])
        rows.append({
            "label": i, "area": area,
            "x": int(stats[i, cv2.CC_STAT_LEFT]), "y": int(stats[i, cv2.CC_STAT_TOP]),
            "width": int(stats[i, cv2.CC_STAT_WIDTH]), "height": int(stats[i, cv2.CC_STAT_HEIGHT]),
            "cx": round(float(cents[i][0]), 2), "cy": round(float(cents[i][1]), 2),
            "kept": area >= min_area,
        })
    return labels, rows


def write_csv(path, rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({**r, "kept": "true" if r["kept"] else "false"})


def describe(mask: np.ndarray, connectivity: int, min_area: int) -> dict:
    h, w = mask.shape
    _, rows = label_components(mask, connectivity, min_area)
    kept = [r for r in rows if r["kept"]]
    fg = int(np.count_nonzero(mask == 255))
    border = [r for r in kept if r["x"] == 0 or r["y"] == 0 or r["x"] + r["width"] == w or r["y"] + r["height"] == h]
    d = {"fg_pixels": fg, "holes": count_holes(mask),
         "components_raw": len(rows), "components_kept": len(kept),
         "area_total_raw": sum(r["area"] for r in rows), "area_total_kept": sum(r["area"] for r in kept),
         "area_sum_matches_fg": sum(r["area"] for r in rows) == fg,
         "kept_touching_border": len(border)}
    for c in (4, 8):
        _, rc = label_components(mask, c, min_area)
        d[f"raw_conn{c}"] = len(rc)
        d[f"kept_conn{c}"] = sum(r["kept"] for r in rc)
    return d


def render_labels(shape, labels, rows) -> np.ndarray:
    out = np.zeros((*shape, 3), np.uint8)
    scale = max(0.4, min(shape) / 900)
    for r in rows:
        sel = labels == r["label"]
        if r["kept"]:
            color = cv2.applyColorMap(np.array([[(r["label"] * 53) % 200 + 40]], np.uint8), cv2.COLORMAP_HSV)[0, 0]
            out[sel] = tuple(int(c) for c in color)
        else:
            out[sel] = (70, 70, 70)
        x, y, w, h = r["x"], r["y"], r["width"], r["height"]
        cv2.rectangle(out, (x, y), (x + w, y + h), (0, 200, 0) if r["kept"] else (0, 0, 255), 1)
        cv2.circle(out, (int(round(r["cx"])), int(round(r["cy"]))), max(2, int(3 * scale)), (0, 255, 255), -1)
        cv2.putText(out, str(r["label"]), (x, max(12, y - 4)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5 * scale + 0.2, (255, 255, 255), 1, cv2.LINE_AA)
    return out


def _write(path: str, img: np.ndarray) -> None:
    if not cv2.imwrite(path, img):
        raise PdiError(f"falha ao gravar {path}")


def run_analyze(input_path: str, prefix: str, connectivity: int, min_area: int,
                steps: list[MorphStep]) -> dict:
    if connectivity not in (4, 8):
        raise PdiError(f"--connectivity deve ser 4 ou 8 (recebido {connectivity})")
    if min_area < 0:
        raise PdiError(f"--min-area deve ser inteiro >= 0 (recebido {min_area})")
    for s in steps:
        validate_step(s)
    mask = cv2.imread(input_path, cv2.IMREAD_UNCHANGED)
    if mask is None:
        raise PdiError(f"não foi possível ler a máscara: {input_path}")
    validate_mask(mask, mask.shape[:2])

    Path(prefix).parent.mkdir(parents=True, exist_ok=True)
    _write(f"{prefix}_initial_mask.png", mask)

    summary = {"input": str(input_path), "image_shape": list(mask.shape), "connectivity": connectivity,
               "min_area": min_area, "stages": []}
    labels, rows = label_components(mask, connectivity, min_area)
    write_csv(f"{prefix}_initial.csv", rows)
    _write(f"{prefix}_initial_labels.png", render_labels(mask.shape, labels, rows))
    summary["initial"] = describe(mask, connectivity, min_area)

    cur = mask
    for i, s in enumerate(steps, 1):
        cur = apply_step(cur, s)
        _write(f"{prefix}_stage{i}_{s.op}.png", cur)
        summary["stages"].append({"stage": i, **asdict(s), **describe(cur, connectivity, min_area)})

    labels, rows = label_components(cur, connectivity, min_area)
    write_csv(f"{prefix}_final.csv", rows)
    _write(f"{prefix}_labels.png", render_labels(cur.shape, labels, rows))
    summary["final"] = describe(cur, connectivity, min_area)
    ratio = summary["initial"]["fg_pixels"] / mask.size
    summary["initial"]["foreground_ratio"] = round(ratio, 4)
    if ratio > 0.5:
        summary["warning"] = "mais da metade dos pixels é 255: confira se o objeto está em branco e o fundo em preto"
    Path(f"{prefix}_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary
