# pdi_lab — Laboratórios M2.1 (segmentação) e M2.2 (componentes conexos e morfologia)

Projeto dos laboratorios técnicos M2.1 e M2.2

## Requisitos e instalação

Python >= 3.9, OpenCV, NumPy. Roda localmente, sem Colab, em Linux/macOS/Windows.

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
```

## Estrutura

```
pdi_lab/            código (segment.py, analyze.py, cli.py)
images/input/       originais, nunca modificados (moedas.png, xicara.png)
images/output/      máscaras PNG da M2.1
results/            saídas da M2.2 (estágios, CSVs, rótulos, resumos)
scripts/            run_experiments.py (M2.1), run_m22.py (M2.2)
tests/              test_segment.py (M2.1), test_analyze.py (M2.2)
docs/               figures/, results.md, results_m22.md (tabelas geradas pelos scripts)
REPORT.md           relatório (seções M2.1 e M2.2)
AI_USAGE.md         declaração de uso de IA
lab.json            metadados da entrega
```

## M2.1 — operação `segment`

```bash
python -m pdi_lab --input IMG --output MASCARA.png --operation segment --method {fixed,otsu,adaptive,hsv} [opções]
```

| Opção | Método | Descrição |
|---|---|---|
| `--threshold T` | fixed | limiar em [0,255]; pixel > T vira 255 (padrão 120) |
| `--invert` | fixed, otsu, adaptive | objeto escuro: usa THRESH_BINARY_INV |
| `--blur K` | todos | pré-processamento: Gaussiana K×K, K ímpar (0 = nenhum, padrão) |
| `--block-size B`, `--C c` | adaptive | vizinhança ímpar >= 3 (padrão 51) e constante subtraída (padrão 5) |
| `--hsv-lower H S V`, `--hsv-upper H S V` | hsv | escala OpenCV: H 0–179, S e V 0–255. Se H_inf > H_sup, a faixa cruza o matiz 179→0 e é tratada como duas faixas unidas |

Saída: PNG, 1 canal, mesmas dimensões da entrada, somente 0 e 255.

### Comandos das configurações do relatório

`moedas.png` (objetos escuros sobre papel claro, caso favorável):

```bash
python -m pdi_lab --input images/input/moedas.png --output images/output/moedas_fixed_mask.png --operation segment --method fixed --threshold 140 --invert
python -m pdi_lab --input images/input/moedas.png --output images/output/moedas_otsu_mask.png --operation segment --method otsu --invert --blur 5
```

`xicara.png` (louça vermelha sobre madeira, caso difícil):

```bash
python -m pdi_lab --input images/input/xicara.png --output images/output/xicara_fixed_mask.png --operation segment --method fixed --threshold 90 --invert
python -m pdi_lab --input images/input/xicara.png --output images/output/xicara_hsv_mask.png --operation segment --method hsv --hsv-lower 0 150 60 --hsv-upper 8 255 255 --blur 5
```

Para regenerar máscaras, figuras e `docs/results.md`: `python scripts/run_experiments.py`.

## M2.2 — operação `analyze`

Entrada: máscara binária (PNG, 1 canal, só 0 e 255), como as geradas por `segment`. `--output` é um **prefixo**.

```bash
python -m pdi_lab --input images/output/moedas_otsu_mask.png --output results/moedas_otsu --operation analyze --connectivity 8 --min-area 20 --morph open:ellipse:5:1,close:ellipse:9:1
python -m pdi_lab --input images/output/xicara_hsv_mask.png --output results/xicara_hsv --operation analyze --connectivity 8 --min-area 20 --morph open:ellipse:5:1,close:ellipse:9:1
```



| Opção | Descrição |
|---|---|
| `--connectivity 4\|8` | conectividade usada nos CSVs, no filtro e na imagem de rótulos (padrão **8**). A contagem com 4 e com 8 na máscara inicial é sempre calculada e guardada no resumo |
| `--min-area N` | inteiro >= 0 (padrão 0 = sem filtro). Componente com área >= N tem `kept=true` |
| `--morph "op:forma:tam:it,..."` | sequência, em ordem. `op`: `open` ou `close`; `forma`: `rect`, `ellipse` ou `cross`; `tam` ímpar; `it` >= 1. Forma, tamanho e iterações são opcionais (padrão `ellipse`, 3, 1) |

Sem `--morph` a máscara não é alterada (só rotula). Nenhum parâmetro morfológico está fixo no código.

Arquivos criados a partir do prefixo (`results/moedas_otsu` nos exemplos):

| Arquivo | Conteúdo |
|---|---|
| `<prefixo>_initial_mask.png` | cópia da máscara inicial (255 = objeto, 0 = fundo) |
| `<prefixo>_initial.csv` | componentes da máscara inicial: `label,area,x,y,width,height,cx,cy,kept` |
| `<prefixo>_initial_labels.png` | rótulos, caixas e centroides da máscara inicial |
| `<prefixo>_stage<N>_<op>.png` | máscara após o estágio N (`_stage1_open.png`, `_stage2_close.png`) |
| `<prefixo>_final.csv` | componentes da máscara final (mesmas colunas) |
| `<prefixo>_labels.png` | rótulos finais: cor por componente, caixa verde (mantido) ou vermelha (filtrado), centroide, número |
| `<prefixo>_summary.json` | conectividade, parâmetros da sequência, contagens brutas e filtradas (inclusive 4 × 8), áreas antes/depois, buracos e dados por estágio |


## Testes

```bash
python -m pytest -q
```

- `tests/test_segment.py` (M2.1): imagem sintética com pixels abaixo, **no** e acima do limiar (regra `> T`) e inversão; Otsu bimodal sintético; faixa HSV que cruza o matiz; as 2 imagens reais × 2 configurações; limitação observável (falso positivo do Otsu no canto inferior esquerdo das moedas); falha de leitura, método desconhecido e parâmetros inválidos, com código de saída 0 × ≠ 0 (inclusive via `subprocess`); verificação de dimensões, canal único e {0,255}; entrada não alterada.
- `tests/test_analyze.py` (M2.2): dois pixels na diagonal (2 componentes em conectividade 4, 1 em 8); ruído isolado + região principal (abertura); furo pequeno (fechamento); ordem e arquivos dos estágios; máscara vazia; objeto na borda; `--connectivity` e demais parâmetros inválidos; máscara colorida ou não binária; flag `kept` do CSV; reexecução das duas imagens com a conferência de que a soma das áreas dos componentes brutos é igual aos pixels de primeiro plano; `segment` ainda funcionando.

