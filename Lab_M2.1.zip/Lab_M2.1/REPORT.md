# REPORT — Laboratório M2.1 e M2.2

Projeto: lab M2-1. Comandos, parâmetros no `README.md`.
Todos os números abaixo vêm de `scripts/run_experiments.py` e `scripts/run_m22.py` (arquivos em `docs/` e `results/`).

# Parte M2.1: máscara binária e segmentação

## 1. Alvo e imagens

| Imagem | Alvo | Por que foi escolhida |
|---|---|---|
| `moedas.png` (1200×896) | cada **objeto metálico**: 4 moedas e 3 arruelas, 7 no total | Caso favoravel: objetos separados sobre papel claro e uniforme, com vários objetos discerníveis. Dificuldades menores: reflexos metálicos, furos nas arruelas e um canto inferior esquerdo mais escuro. |
| `xicara.png` (400×600) | a **louça vermelha** (xícara por fora + pires) | Caso difícil: a cor do alvo é próxima da madeira do fundo, sombra sob o pires, reflexos na colher e o interior branco da xícara.|

## 2. Configurações e parâmetros

Todas gravam PNG de 1 canal com {0,255}, validado ao gravar e ao reler do disco.

| Imagem | Configuração | Pré-processamento | Parâmetros | Objeto escuro? |
|---|---|---|---|---|
| moedas | fixed | nenhum | T=140, `--invert` | **sim**: objetos mais escuros que o papel (fundo ≈ cinza 215–233) |
| moedas | **otsu** | Gaussiana 5×5 | T calculado = 165, `--invert` | sim |
| xicara | fixed | nenhum | T=90, `--invert` | **sim**: louça ≈ cinza 70 (amostras pontuais) |
| xicara | **hsv** | Gaussiana 5×5 antes da conversão | H∈[0,8], S∈[150,255], V∈[60,255] (escala OpenCV) | não se aplica |

Pré-processamento: a Gaussiana 5×5 segue o tutorial de limiarização do OpenCV e foi aplicada ao Otsu e ao HSV, mas não ao limiar fixo. Logo a comparação fixed × segundo método mistura dois efeitos: o método e a suavização.

## 3. Resultados

Proporção de primeiro plano (imagem inteira como denominador; pixels em `docs/results.md`):

| Imagem | Configuração | Proporção |
|---|---|---|
| moedas | fixed (T=140, invertido) | 15,2% |
| moedas | otsu (invertido, blur 5) | 18,3% |
| xicara | fixed (T=90, invertido) | 42,7% |
| xicara | hsv | 25,4% |

![moedas](docs/figures/fig_moedas.png)

*Figura 1 — Moedas e arruelas. Em cima: original e máscaras (branco = objeto). Embaixo: sobreposição em verde sobre o original. Os erros são avaliados a olho; não há máscara de referência.*

![xicara](docs/figures/fig_xicara.png)

*Figura 2 — Xícara, mesma organização da Figura 1, com as configurações fixed e hsv.*

## 4. Configuração de trabalho para o M2.2

**Escolha: `moedas.png` + Otsu invertido com Gaussiana 5×5** (`images/output/moedas_otsu_mask.png`), por deixar os objetos mais completos:

- **Acertos visíveis:** os 7 objetos aparecem como regiões compactas; as faces das moedas ficam preenchidas e os furos das arruelas ficam como fundo. O limiar fixo T=140 deixa buracos nas faces das moedas.
- **Falsos positivos visíveis:** o canto inferior esquerdo (só papel, mais escuro) vira um 8º componente: 59,5% do trecho de 96×100 px desse canto sai como objeto (teste `test_sombra_canto`), contra 2,1% no limiar fixo T=140.
- **Falsos negativos visíveis:** o brilho forte da arruela grande é claro demais e fica de fora nos dois métodos, abrindo uma falha na borda dela; no fixed, as faces de várias moedas ficam pontilhadas.

Trade-off: o fixed T=140 dá 7 componentes grandes, mas com as faces furadas; o Otsu preenche melhor, mas traz o componente extra do canto.

Para a xícara, a melhor máscara é a **HSV**: cobre xícara por fora e pires e deixa de fora o interior branco, o café e a colher. Falhas visíveis: a sombra sob o pires e a borda inferior ficam de fora, e há manchas de madeira na borda do pires. O fixed invertido captura o pires, mas leva junto o fundo escuro do canto superior esquerdo e veios escuros da madeira.

## 5. Discussão comparativa

**(a) Quando o limiar fixo funcionou e falhou.** Nas moedas funcionou: com T=140 os 7 objetos viram 7 componentes de ≥500 px sem suavização. Falhou em dois pontos: com T=120 os objetos se partem e o brilho da arruela grande nunca entra. Na xícara, o cinza descarta a informação de cor, justamente o que distingue a louça.

**(b) Parâmetro mais sensível.** Variando um parâmetro por vez com a própria CLI: nas moedas, o limiar T no fixed invertido (T=120/140/160/210 dá 12,0%/15,2%/17,4%/25,8%; componentes ≥500 px: 13, 7, 8, 8; a partir de T=160 o canto escuro vira componente extra). Na xícara com HSV, o **limite superior de matiz**: H_sup 8→12 sobe a proporção de 25,4% para 60,4% (a madeira começa em H≈11 nas amostras), enquanto S_inf 150→100/200 mexe cerca de ±1 ponto e V_inf 60→30/100 dá 31,8%/20,7%. Isso é proporção de primeiro plano, não acerto.

**(c) Erros que atrapalham a contagem no M2.2.** (1) O componente do canto no Otsu faz a contagem dar 8 em vez de 7. (2) Fragmentação, ao partir os objetos (fixed com T=120). (3) Buracos e falhas (faces das moedas, brilho da arruela) deformam área e contorno. (4) Na xícara, xícara e pires encostam e tendem a formar um só componente. Contagens de componentes descrevem a máscara e **não** são acurácia.

## 6. Limitações

- Sem máscara de referência, não conseguimos um resultado 100% preciso: falsos positivos/negativos são por observação visual; proporções e contagens descrevem a máscara.
- Parâmetros ajustados olhando as próprias duas imagens; sem garantia de generalização.
---

# Parte M2.2 — componentes conexos e sequência morfológica

## M2.2.1 Casos e parâmetros

| Caso | Máscara inicial (M2.1) | Objetos reais |
|---|---|---|
| `moedas_otsu` | Otsu invertido, blur 5 | 7|
| `xicara_hsv` | HSV H∈[0,8], S≥150, V≥60 (componentes pequenos e contato xícara/pires) | 2 (xícara e pires) |

Objeto em branco (255) e fundo em preto (0); a cópia da máscara inicial fica em `results/<caso>_initial_mask.png`.

Parâmetros comuns: conectividade **8**, `--min-area 20`, sequência **abertura (elipse 5×5, 1 iteração) → fechamento (elipse 9×9, 1 iteração)**. Critério de filtro: componente com área < 20 px recebe `kept=false` no CSV, igual na máscara inicial e na final; o fundo (rótulo 0) nunca entra nos CSVs.

## M2.2.2 Sequência e justificativa

| # | Operação | Problema visado | Por que nesta ordem/tamanho |
|---|---|---|---|
| 1 | abertura elipse 5×5 | grãos isolados de 1 a 5 px (na `moedas_otsu`, 9 dos 17 componentes iniciais) e fios finos de madeira na `xicara_hsv` | vem primeiro para remover o ruído antes que o fechamento o una aos objetos |
| 2 | fechamento elipse 9×9 | pequenos buracos nos objetos (relevos das moedas, reflexos) | vem depois; 9 px fecha buracos pequenos sem criar pontes entre objetos separados nestas imagens |

Os tamanhos (5 e 9) foram escolhidos testando nas mesmas imagens; não há garantia fora delas.

## M2.2.3 Figuras por estágio

![moedas_otsu](docs/figures/m22_moedas_otsu.png)

*Figura 3 — `moedas_otsu`: máscara inicial, após abertura, após fechamento e rótulos finais (cor por componente; caixa verde = mantido, vermelha = filtrado; ponto amarelo = centroide).*

![xicara_hsv](docs/figures/m22_xicara_hsv.png)

*Figura 4 — `xicara_hsv`: xícara e pires em contato aparecem como um único componente.*

## M2.2.4 Componentes antes e depois

Conectividade 8, área mínima 20:

| Caso | Contagem visual | Brutos antes → depois | Mantidos antes → depois | Área de primeiro plano (px) antes → depois | Buracos antes → depois |
|---|---|---|---|---|---|
| moedas_otsu | 7 | 17 → 8 | 8 → 8 | 196.884 → 199.219 | 153 → 11 |
| xicara_hsv | 2 | 103 → 17 | 26 → 13 | 61.009 → 61.693 | 81 → 4 |


## M2.2.5 Conectividade 4 × 8

Mesma máscara inicial, mesmos parâmetros (área mínima 20):

| Caso | Brutos conn 4 | Brutos conn 8 | Mantidos conn 4 | Mantidos conn 8 |
|---|---|---|---|---|
| moedas_otsu | 25 | 17 | 8 | 8 |
| xicara_hsv | 143 | 103 | 26 | 26 |

A conectividade 4 só liga pixels que se tocam pelos lados; a 8 também liga os diagonais. Por isso a 4 gera mais componentes brutos: em bordas serrilhadas e grãos (HSV na madeira, ruído do Otsu) pixels diagonais viram componentes separados. Depois do filtro de 20 px a diferença desaparece nos dois casos (8 e 8; 26 e 26), porque os componentes grandes são os mesmos. A análise final usa 8, natural para contornos arredondados em grade de pixels; o teste sintético de dois pixels na diagonal confirma 2 componentes em 4 e 1 em 8.

## M2.2.6 Quando a sequência ajuda e quando atrapalha ou não resolve

- **Ajuda:** em `moedas_otsu` os buracos caem de 153 para 11 e os componentes brutos de 17 para 8, mantendo os 7 objetos (áreas de 13.471 a 41.600 px no CSV final).
- **Não resolve (fundo):** o canto inferior esquerdo (papel mais escuro) forma um componente de 5.790 px que sobrevive à abertura e ao fechamento (5.768 px no final) e toca a borda; é contado como 8º objeto e o filtro de 20 px não o remove.
- **Não resolve (contato):** em `xicara_hsv` xícara e pires formam um único componente de 56.960 px na máscara inicial e 59.459 px na final; o contato é largo, a abertura 5×5 não o separa e o fechamento só aumenta a massa. Separar exigiria outras técnicas (erosão forte, watershed), não testadas.
- **Efeito indesejado:** em `xicara_hsv` a abertura remove 2.772 px (−4,5%) antes de o fechamento devolver 3.456 px, ou seja, o contorno muda nos dois sentidos; e a sequência deixa 12 componentes pequenos acima de 20 px (fios de madeira e reflexos, Figura 4).

## M2.2.7 Contagem automática × interpretação humana

| Caso | Contagem visual | Componentes mantidos (≥20) |
|---|---|---|
| moedas_otsu | 7 | 8 |
| xicara_hsv | 2 | 13 |

A contagem só se aproxima da leitura humana quando os objetos estão separados e nada além deles sobrevive à limpeza (moedas: 8 contra 7). Difere do número real por: (i) **fundo contado como objeto** (canto do papel); (ii) **contato** (xícara e pires contam 1, não 2); (iii) **ruído com área acima do filtro** (veios de madeira). A contagem descreve a máscara; a contagem visual de 7 e 2 foi feita pelo autor olhando as fotos e não é máscara de referência, portanto não declaro acurácia nem revocação.

## M2.2.8 Limitações

- Parâmetros ajustados nas mesmas imagens do estudo (2 fotos); sem validação externa e sem máscara de referência.

## Referências

- OPENCV. Changing Colorspaces. OpenCV-Python Tutorials. Disponível em: https://docs.opencv.org/4.x/df/d9d/tutorial_py_colorspaces.html.

- OPENCV. Image Thresholding. OpenCV-Python Tutorials. Disponível em: https://docs.opencv.org/4.x/d7/d4d/tutorial_py_thresholding.html.

- OpenCV. Morphological Transformations. Disponível em: https://docs.opencv.org/4.13.0/d9/d61/tutorial_py_morphological_ops.html.

- OpenCV. Structural Analysis and Shape Descriptors. Disponível em: https://docs.opencv.org/4.x/d3/dc0/group__imgproc__shape.html.

- PAUL. Detect red circles in an image using OpenCV. Solarian Programmer, 8 maio 2015. Disponível em: https://solarianprogrammer.com/2015/05/08/detect-red-circles-image-using-opencv/. Acesso em: 20 out. 2026. 

- ROSEBROCK, Adrian. OpenCV Connected Component Labeling and Analysis. PyImageSearch, 22 fev. 2021. Disponível em: https://pyimagesearch.com/2021/02/22/opencv-connected-component-labeling-and-analysis/.

