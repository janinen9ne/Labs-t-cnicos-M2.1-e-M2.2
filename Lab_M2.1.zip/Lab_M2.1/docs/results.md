| Imagem | Configuração | Argumentos | Pixels de objeto | Proporção |
|---|---|---|---|---|
| moedas | fixed | `--method fixed --threshold 140 --invert` | 163204 | 15.2% |
| moedas | otsu | `--method otsu --invert --blur 5` | 196884 | 18.3% |
| xicara | fixed | `--method fixed --threshold 90 --invert` | 102520 | 42.7% |
| xicara | hsv | `--method hsv --hsv-lower 0 150 60 --hsv-upper 8 255 255 --blur 5` | 61009 | 25.4% |
