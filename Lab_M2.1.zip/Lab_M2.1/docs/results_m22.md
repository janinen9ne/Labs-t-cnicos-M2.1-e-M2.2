## Antes/depois (conectividade 8, área mínima 20, sequência open:ellipse:5:1,close:ellipse:9:1)

| caso | contagem manual | componentes brutos antes → depois | mantidos (área>=20) antes → depois | área total de fg antes → depois | buracos antes → depois |
|---|---|---|---|---|---|
| moedas_otsu | 7 | 17 → 8 | 8 → 8 | 196884 → 199219 | 153 → 11 |
| xicara_hsv | 2 | 103 → 17 | 26 → 13 | 61009 → 61693 | 81 → 4 |

## Conectividade 4 × 8 na máscara inicial (mesma máscara, mesma área mínima)

| caso | brutos conn4 | brutos conn8 | mantidos conn4 | mantidos conn8 |
|---|---|---|---|---|
| moedas_otsu | 25 | 17 | 8 | 8 |
| xicara_hsv | 143 | 103 | 26 | 26 |

## Estágios (efeito de cada operação)

| caso | estágio | operação | pixels fg | buracos | brutos | mantidos |
|---|---|---|---|---|---|---|
| moedas_otsu | 0 | inicial | 196884 | 153 | 17 | 8 |
| moedas_otsu | 1 | open ellipse 5x5 it=1 | 195610 | 113 | 13 | 11 |
| moedas_otsu | 2 | close ellipse 9x9 it=1 | 199219 | 11 | 8 | 8 |
| xicara_hsv | 0 | inicial | 61009 | 81 | 103 | 26 |
| xicara_hsv | 1 | open ellipse 5x5 it=1 | 58237 | 28 | 33 | 23 |
| xicara_hsv | 2 | close ellipse 9x9 it=1 | 61693 | 4 | 17 | 13 |
