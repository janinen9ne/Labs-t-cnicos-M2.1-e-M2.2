import json
import subprocess
import sys
from pathlib import Path

import cv2
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pdi_lab import analyze as ana

CONNECTIVITY, MIN_AREA = 8, 20
MORPH = "open:ellipse:5:1,close:ellipse:9:1"

CASES = [
    ("moedas_otsu", "images/output/moedas_otsu_mask.png", 7),
    ("xicara_hsv", "images/output/xicara_hsv_mask.png", 2),
]


def run_cli(name, inp):
    cmd = [sys.executable, "-m", "pdi_lab", "--input", str(ROOT / inp), "--output", str(ROOT / "results" / name),
           "--operation", "analyze", "--connectivity", str(CONNECTIVITY), "--min-area", str(MIN_AREA),
           "--morph", MORPH]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"falhou: {' '.join(cmd)}\n{r.stderr}")
    return json.loads((ROOT / "results" / f"{name}_summary.json").read_text(encoding="utf-8"))


def figure(name, s):
    fig, ax = plt.subplots(1, 4, figsize=(16, 3.6))
    pre = ROOT / "results" / name
    panels = [
        (cv2.imread(f"{pre}_initial_mask.png", 0), f"inicial: {s['initial']['components_raw']} brutos / "
                                                  f"{s['initial']['components_kept']} mantidos", "gray"),
        (cv2.imread(f"{pre}_stage1_open.png", 0), f"1) abertura elipse 5: {s['stages'][0]['components_raw']} / "
                                                 f"{s['stages'][0]['components_kept']}", "gray"),
        (cv2.imread(f"{pre}_stage2_close.png", 0), f"2) fechamento elipse 9: {s['stages'][1]['components_raw']} / "
                                                  f"{s['stages'][1]['components_kept']}", "gray"),
        (cv2.cvtColor(cv2.imread(f"{pre}_labels.png"), cv2.COLOR_BGR2RGB),
         f"rótulos finais (conn {s['connectivity']}, área>={s['min_area']})", None),
    ]
    for a, (img, title, cmap) in zip(ax, panels):
        a.imshow(img, cmap=cmap, vmin=0, vmax=255) if cmap else a.imshow(img)
        a.set_title(title, fontsize=10)
        a.set_xticks([]); a.set_yticks([])
    fig.tight_layout()
    fig.savefig(ROOT / "docs/figures" / f"m22_{name}.png", dpi=100)
    plt.close(fig)

def main():
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "docs/figures").mkdir(parents=True, exist_ok=True)
    L = ["## Antes/depois (conectividade 8, área mínima 20, sequência " + MORPH + ")", "",
         "| caso | contagem manual | componentes brutos antes → depois | mantidos (área>=20) antes → depois | "
         "área total de fg antes → depois | buracos antes → depois |", "|---|---|---|---|---|---|"]
    summaries = {}
    for name, inp, manual in CASES:
        s = run_cli(name, inp)
        summaries[name] = s
        figure(name, s)
        i, f = s["initial"], s["final"]
        L.append(f"| {name} | {manual} | {i['components_raw']} → {f['components_raw']} | "
                 f"{i['components_kept']} → {f['components_kept']} | {i['fg_pixels']} → {f['fg_pixels']} | "
                 f"{i['holes']} → {f['holes']} |")
    L += ["", "## Conectividade 4 × 8 na máscara inicial (mesma máscara, mesma área mínima)", "",
          "| caso | brutos conn4 | brutos conn8 | mantidos conn4 | mantidos conn8 |", "|---|---|---|---|---|"]
    for name, s in summaries.items():
        i = s["initial"]
        L.append(f"| {name} | {i['raw_conn4']} | {i['raw_conn8']} | {i['kept_conn4']} | {i['kept_conn8']} |")
    L += ["", "## Estágios (efeito de cada operação)", "",
          "| caso | estágio | operação | pixels fg | buracos | brutos | mantidos |", "|---|---|---|---|---|---|---|"]
    for name, s in summaries.items():
        i = s["initial"]
        L.append(f"| {name} | 0 | inicial | {i['fg_pixels']} | {i['holes']} | {i['components_raw']} | {i['components_kept']} |")
        for st in s["stages"]:
            L.append(f"| {name} | {st['stage']} | {st['op']} {st['shape']} {st['size']}x{st['size']} it={st['iterations']} | "
                     f"{st['fg_pixels']} | {st['holes']} | {st['components_raw']} | {st['components_kept']} |")

    (ROOT / "docs/results_m22.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))


if __name__ == "__main__":
    main()
