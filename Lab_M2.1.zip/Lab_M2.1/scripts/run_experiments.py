import subprocess
import sys
from pathlib import Path

import cv2
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
IN, OUT, FIG = ROOT / "images/input", ROOT / "images/output", ROOT / "docs/figures"

CONFIGS = [
    ("moedas", "fixed", ["--method", "fixed", "--threshold", "140", "--invert"]),
    ("moedas", "otsu", ["--method", "otsu", "--invert", "--blur", "5"]),
    ("xicara", "fixed", ["--method", "fixed", "--threshold", "90", "--invert"]),
    ("xicara", "hsv", ["--method", "hsv", "--hsv-lower", "0", "150", "60",
                       "--hsv-upper", "8", "255", "255", "--blur", "5"]),
]

def overlay(bgr, mask):
    out = bgr.copy()
    green = np.zeros_like(bgr)
    green[:, :] = (0, 255, 0)
    m = mask == 255
    out[m] = cv2.addWeighted(bgr, 0.5, green, 0.5, 0)[m]
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    FIG.mkdir(parents=True, exist_ok=True)
    rows = []
    for img, label, extra in CONFIGS:
        mask_p = OUT / f"{img}_{label}_mask.png"
        cmd = [sys.executable, "-m", "pdi_lab", "--input", str(IN / f"{img}.png"),
               "--output", str(mask_p), "--operation", "segment"]  + extra
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if r.returncode != 0:
            raise SystemExit(f"falhou: {' '.join(cmd)}\n{r.stderr}")
        m = cv2.imread(str(mask_p), cv2.IMREAD_UNCHANGED)
        rows.append((img, label, extra, int(np.count_nonzero(m == 255)), m.size))
    lines = ["| Imagem | Configuração | Argumentos | Pixels de objeto | Proporção |", "|---|---|---|---|---|"]
    for img, label, extra, fg, total in rows:
        lines.append(f"| {img} | {label} | `{' '.join(extra)}` | {fg} | {fg / total * 100:.1f}% |")
    (ROOT / "docs/results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    for img in ("moedas", "xicara"):
        labels = [l for i, l, *_ in rows if i == img]
        bgr = cv2.imread(str(IN / f"{img}.png"))
        fig, ax = plt.subplots(2, len(labels) + 1, figsize=(4 * (len(labels) + 1), 6))
        ax[0, 0].imshow(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)); ax[0, 0].set_title("original")
        ax[1, 0].axis("off")
        for k, l in enumerate(labels, 1):
            m = cv2.imread(str(OUT / f"{img}_{l}_mask.png"), cv2.IMREAD_UNCHANGED)
            ax[0, k].imshow(m, cmap="gray", vmin=0, vmax=255); ax[0, k].set_title(f"máscara {l}")
            ax[1, k].imshow(cv2.cvtColor(overlay(bgr, m), cv2.COLOR_BGR2RGB)); ax[1, k].set_title(f"sobreposição {l}")
        for a in ax.ravel():
            a.set_xticks([]); a.set_yticks([])
        fig.tight_layout(); fig.savefig(FIG / f"fig_{img}.png", dpi=110); plt.close(fig)


if __name__ == "__main__":
    main()
