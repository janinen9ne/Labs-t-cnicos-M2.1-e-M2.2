import csv
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pdi_lab import analyze as ana
from pdi_lab.cli import run

MOEDAS = ROOT / "images/input/moedas.png"
XICARA = ROOT / "images/input/xicara.png"
HEADER = ["label", "area", "x", "y", "width", "height", "cx", "cy", "kept"]


def save_mask(tmp_path, arr, name="m.png"):
    p = tmp_path / name
    cv2.imwrite(str(p), arr.astype(np.uint8))
    return p

def analyze(tmp_path, mask_path, *extra):
    prefix = tmp_path / "res" / "case"
    code = run(["--input", str(mask_path), "--output", str(prefix), "--operation", "analyze", *extra])
    return code, prefix

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def summary(prefix):
    return json.loads(Path(f"{prefix}_summary.json").read_text(encoding="utf-8"))

def test_diagonal(tmp_path):
    m = np.zeros((5, 5), np.uint8)
    m[1, 1] = m[2, 2] = 255
    _, rows4 = ana.label_components(m, 4)
    _, rows8 = ana.label_components(m, 8)
    assert len(rows4) == 2 and len(rows8) == 1

    code, prefix = analyze(tmp_path, save_mask(tmp_path, m), "--connectivity", "8")
    assert code == 0
    s = summary(prefix)
    assert s["initial"]["raw_conn4"] == 2 and s["initial"]["raw_conn8"] == 1

def test_abertura_remove_ruido(tmp_path):
    m = np.zeros((30, 30), np.uint8)
    m[10:20, 10:20] = 255
    m[2, 2] = 255
    code, prefix = analyze(tmp_path, save_mask(tmp_path, m), "--morph", "open:rect:3:1")
    assert code == 0
    s = summary(prefix)
    assert s["initial"]["components_raw"] == 2 and s["final"]["components_raw"] == 1
    assert s["final"]["fg_pixels"] == 100
    final = cv2.imread(f"{prefix}_stage1_open.png", cv2.IMREAD_UNCHANGED)
    assert final[2, 2] == 0 and (final[10:20, 10:20] == 255).all()

def test_fechamento_preenche_furo(tmp_path):
    m = np.zeros((30, 30), np.uint8)
    m[8:22, 8:22] = 255
    m[15, 15] = 0
    code, prefix = analyze(tmp_path, save_mask(tmp_path, m), "--morph", "close:rect:3:1")
    assert code == 0
    s = summary(prefix)
    assert s["initial"]["holes"] == 1 and s["final"]["holes"] == 0
    assert s["final"]["fg_pixels"] == s["initial"]["fg_pixels"] + 1

def test_sequencia_morfologica(tmp_path):
    m = np.zeros((30, 30), np.uint8)
    m[8:22, 8:22] = 255
    m[2, 2] = 255
    code, prefix = analyze(tmp_path, save_mask(tmp_path, m), "--morph", "open:ellipse:3:1,close:rect:3:1")
    assert code == 0
    assert Path(f"{prefix}_stage1_open.png").exists() and Path(f"{prefix}_stage2_close.png").exists()
    s = summary(prefix)
    assert [(st["op"], st["shape"], st["size"], st["iterations"]) for st in s["stages"]] == [
        ("open", "ellipse", 3, 1), ("close", "rect", 3, 1)]

def test_mascara_vazia(tmp_path):
    code, prefix = analyze(tmp_path, save_mask(tmp_path, np.zeros((10, 12), np.uint8)),
                           "--morph", "open:rect:3:1,close:rect:3:1")
    assert code == 0
    s = summary(prefix)
    assert s["initial"]["components_raw"] == 0 and s["final"]["components_raw"] == 0
    assert read_csv(f"{prefix}_initial.csv") == [] and read_csv(f"{prefix}_final.csv") == []

def test_objeto_na_borda(tmp_path):
    m = np.zeros((20, 20), np.uint8)
    m[0:6, 0:6] = 255
    code, prefix = analyze(tmp_path, save_mask(tmp_path, m))
    assert code == 0
    rows = read_csv(f"{prefix}_initial.csv")
    assert len(rows) == 1
    r = rows[0]
    assert (r["area"], r["x"], r["y"], r["width"], r["height"]) == ("36", "0", "0", "6", "6")
    assert float(r["cx"]) == 2.5 and float(r["cy"]) == 2.5

    assert summary(prefix)["initial"]["holes"] == 0

def test_parametros_invalidos(tmp_path):
    good = save_mask(tmp_path, np.zeros((5, 5), np.uint8))
    for extra in (["--connectivity", "6"], ["--connectivity", "0"], ["--min-area", "-1"],
                  ["--morph", "blur:ellipse:3:1"], ["--morph", "open:circle:3:1"],
                  ["--morph", "open:ellipse:4:1"], ["--morph", "open:ellipse:3:0"],
                  ["--morph", "open:ellipse:x:1"], ["--morph", "erode:ellipse:3:1"]):
        code, _ = analyze(tmp_path, good, *extra)
        assert code != 0, extra
    code, _ = analyze(tmp_path, tmp_path / "nao_existe.png")
    assert code != 0

def test_rejeita_mascara_invalida(tmp_path):
    gray = np.zeros((5, 5), np.uint8)
    gray[2, 2] = 128
    assert analyze(tmp_path, save_mask(tmp_path, gray))[0] != 0
    color = np.zeros((5, 5, 3), np.uint8)
    assert analyze(tmp_path, save_mask(tmp_path, color, "c.png"))[0] != 0

def test_area_minima_csv(tmp_path):
    m = np.zeros((30, 30), np.uint8)
    m[5:15, 5:15] = 255
    m[22:24, 22:24] = 255
    code, prefix = analyze(tmp_path, save_mask(tmp_path, m), "--min-area", "20")
    assert code == 0
    rows = read_csv(f"{prefix}_initial.csv")
    assert list(rows[0].keys()) == HEADER
    kept = {int(r["area"]): r["kept"] for r in rows}
    assert kept == {100: "true", 4: "false"}
    s = summary(prefix)
    assert s["initial"]["components_raw"] == 2 and s["initial"]["components_kept"] == 1

STUDY = [
    (MOEDAS, ["--method", "otsu", "--invert", "--blur", "5"]),
    (XICARA, ["--method", "hsv", "--hsv-lower", "0", "150", "60", "--hsv-upper", "8", "255", "255",
              "--blur", "5"]),
]

@pytest.mark.parametrize("img,seg_args", STUDY, ids=["moedas", "xicara"])
def test_fluxo_completo_imagens(img, seg_args, tmp_path):
    mask = tmp_path / "mask.png"
    assert run(["--input", str(img), "--output", str(mask), "--operation", "segment", *seg_args]) == 0
    fg = int(np.count_nonzero(cv2.imread(str(mask), cv2.IMREAD_UNCHANGED) == 255))
    code, prefix = analyze(tmp_path, mask, "--connectivity", "8", "--min-area", "20",
                           "--morph", "open:ellipse:5:1,close:ellipse:9:1")
    assert code == 0
    for suffix in ("initial_mask.png", "initial.csv", "initial_labels.png", "stage1_open.png",
                   "stage2_close.png", "final.csv", "labels.png", "summary.json"):
        assert Path(f"{prefix}_{suffix}").exists(), suffix

    raw = read_csv(f"{prefix}_initial.csv")
    assert sum(int(r["area"]) for r in raw) == fg
    final_fg = int(np.count_nonzero(cv2.imread(f"{prefix}_stage2_close.png", cv2.IMREAD_UNCHANGED) == 255))
    assert sum(int(r["area"]) for r in read_csv(f"{prefix}_final.csv")) == final_fg

    assert (cv2.imread(f"{prefix}_initial_mask.png", cv2.IMREAD_UNCHANGED)
            == cv2.imread(str(mask), cv2.IMREAD_UNCHANGED)).all()

    for st in ("stage1_open", "stage2_close"):
        m = cv2.imread(f"{prefix}_{st}.png", cv2.IMREAD_UNCHANGED)
        assert m.ndim == 2 and set(np.unique(m).tolist()) <= {0, 255}
    s = summary(prefix)
    assert s["initial"]["area_sum_matches_fg"] and s["final"]["area_sum_matches_fg"]
    assert s["initial"]["raw_conn4"] >= s["initial"]["raw_conn8"]

def test_segmentacao_apos_m22(tmp_path):
    out = tmp_path / "m.png"
    assert run(["--input", str(MOEDAS), "--output", str(out), "--operation", "segment",
                "--method", "fixed", "--threshold", "140", "--invert"]) == 0
