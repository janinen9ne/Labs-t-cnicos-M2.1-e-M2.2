import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pdi_lab import segment as seg
from pdi_lab.cli import run

MOEDAS = ROOT / "images/input/moedas.png"
XICARA = ROOT / "images/input/xicara.png"

def check_binary_file(path, shape_hw):
    m = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    assert m is not None
    assert m.ndim == 2, "máscara deve ter 1 canal"
    assert m.shape == shape_hw
    assert set(np.unique(m).tolist()) <= {0, 255}
    return m

def test_limiar_fixo(tmp_path):
    vals = np.array([[0, 99, 100, 101, 255]], dtype=np.uint8)
    bgr = cv2.cvtColor(vals, cv2.COLOR_GRAY2BGR)
    src, out = tmp_path / "s.png", tmp_path / "s_mask.png"
    cv2.imwrite(str(src), bgr)
    assert run(["--input", str(src), "--output", str(out), "--operation", "segment",
                "--method", "fixed", "--threshold", "100"]) == 0
    m = check_binary_file(out, (1, 5))
    assert m.tolist() == [[0, 0, 0, 255, 255]]

    out_inv = tmp_path / "s_inv.png"
    assert run(["--input", str(src), "--output", str(out_inv), "--operation", "segment",
                "--method", "fixed", "--threshold", "100", "--invert"]) == 0
    assert cv2.imread(str(out_inv), cv2.IMREAD_UNCHANGED).tolist() == [[255, 255, 255, 0, 0]]

def test_otsu_bimodal():
    g = np.full((20, 20), 40, np.uint8)
    g[:, 10:] = 200
    mask, p = seg.segment_otsu(cv2.cvtColor(g, cv2.COLOR_GRAY2BGR), False, 0)
    assert (mask[:, 10:] == 255).all() and (mask[:, :10] == 0).all()
    assert 40 <= p["threshold_otsu"] < 200

def test_hsv_circular():
    hsv = np.array([[[2, 255, 255], [178, 255, 255], [90, 255, 255]]], np.uint8)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    mask, _ = seg.segment_hsv(bgr, [170, 100, 100], [10, 255, 255], 0)
    assert mask.tolist() == [[255, 255, 0]]
    mask2, _ = seg.segment_hsv(bgr, [0, 100, 100], [10, 255, 255], 0)
    assert mask2.tolist() == [[255, 0, 0]]

REAL = [
    (MOEDAS, ["--method", "fixed", "--threshold", "140", "--invert"]),
    (MOEDAS, ["--method", "otsu", "--invert", "--blur", "5"]),
    (XICARA, ["--method", "fixed", "--threshold", "90", "--invert"]),
    (XICARA, ["--method", "hsv", "--hsv-lower", "0", "150", "60", "--hsv-upper", "8", "255", "255",
              "--blur", "5"]),
]

@pytest.mark.parametrize("img,extra", REAL, ids=lambda x: x.stem if isinstance(x, Path) else x[1])
def test_imagens_reais(img, extra, tmp_path):
    out = tmp_path / "m.png"
    assert run(["--input", str(img), "--output", str(out), "--operation", "segment"] + extra) == 0
    shape = cv2.imread(str(img)).shape[:2]
    m = check_binary_file(out, shape)
    assert 0 < (m == 255).mean() < 1

def test_sombra_canto(tmp_path):
    def corner(extra):
        out = tmp_path / "m.png"
        assert run(["--input", str(MOEDAS), "--output", str(out), "--operation", "segment"] + extra) == 0
        m = cv2.imread(str(out), cv2.IMREAD_UNCHANGED)
        return (m[800:896, 0:100] == 255).mean()

    assert corner(["--method", "otsu", "--invert", "--blur", "5"]) > 0.5
    assert corner(["--method", "fixed", "--threshold", "140", "--invert"]) < 0.1

def test_limites_hsv():
    bgr = cv2.imread(str(XICARA))
    with pytest.raises(seg.PdiError):
        seg.segment_hsv(bgr, [0, 0, 0], [200, 255, 255], 0)

def base(tmp_path, *extra, inp=MOEDAS):
    return ["--input", str(inp), "--output", str(tmp_path / "o.png"), "--operation", "segment", *extra]

def test_codigo_saida(tmp_path):
    assert run(base(tmp_path, "--method", "fixed", "--threshold", "120")) == 0
    assert run(base(tmp_path, inp=tmp_path / "nao_existe.png")) != 0
    assert run(base(tmp_path, "--method", "xyz")) != 0
    assert run(base(tmp_path, "--method", "fixed", "--threshold", "300")) != 0
    assert run(base(tmp_path, "--method", "adaptive", "--block-size", "10")) != 0
    assert run(base(tmp_path, "--method", "fixed", "--blur", "4")) != 0
    assert run(base(tmp_path, "--method", "hsv")) != 0
    assert run(["--input", str(MOEDAS), "--output", str(tmp_path / "o.jpg"),
                "--operation", "segment"]) != 0
    assert run(["--input", str(MOEDAS), "--output", str(tmp_path / "o.png"),
                "--operation", "blur"]) != 0

def test_cli(tmp_path):
    cmd = [sys.executable, "-m", "pdi_lab", "--input", str(MOEDAS), "--output", str(tmp_path / "o.png"),
           "--operation", "segment", "--method", "otsu"]
    ok = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    assert ok.returncode == 0 and "binary=OK" in ok.stdout
    bad = subprocess.run(cmd[:-1] + ["nope"], cwd=ROOT, capture_output=True, text=True)
    assert bad.returncode != 0 and "método desconhecido" in bad.stderr

def test_input(tmp_path):
    before = MOEDAS.read_bytes()
    run(base(tmp_path))
    assert MOEDAS.read_bytes() == before

def test_rejeita_mascaras_invalidas():
    ok = np.zeros((4, 4), np.uint8)
    ok[1, 1] = 255
    assert seg.validate_mask(ok, (4, 4))["foreground_pixels"] == 1
    with pytest.raises(seg.PdiError):
        seg.validate_mask(np.full((4, 4), 128, np.uint8), (4, 4))
    with pytest.raises(seg.PdiError):
        seg.validate_mask(np.zeros((4, 4, 3), np.uint8), (4, 4))
    with pytest.raises(seg.PdiError):
        seg.validate_mask(ok, (5, 4))
