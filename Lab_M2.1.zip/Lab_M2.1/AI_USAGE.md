# Uso de IA

* **Ferramenta utilizada:** Claude (Anthropic).

## `README.md`

A IA foi utilizada como apoio na organização visual e textual.

## `run_experiments.py` e `run_m22.py`

Foi utilizado como auxilio para criação dos scripts e para interpretação dos resultados.

## Imagens

Colagem final das figuras para o REPORT.md na seção de resultados.

## Testes
Auxilio na criação dos testes:

`test_fluxo_completo_imagens`

`test_parametros_invalidos`

`test_imagens_reais`

`test_codigos_saida`

`test_rejeita_mascaras_invalidas`

`test_abertura_remove_ruido`

## Código
- Correção de sintaxe e estrutura do código